package com.example.saira_000.connect4game;

public class AIPlayer {

    public int babyLevel(){
        int randomInt = (int)(6.0 * Math.random());
        return  randomInt;
    }
}
